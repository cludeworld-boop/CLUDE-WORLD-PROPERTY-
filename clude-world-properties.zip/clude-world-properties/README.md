# Clude World Properties Website

A complete, premium real estate website for Clude World Properties Nigeria.

## Files Included

```
clude-world-properties/
├── index.html          ← Main website (all pages in one file)
├── README.md           ← This file
└── assets/
    ├── css/
    │   └── styles.css  ← Extracted stylesheet (for reference)
    └── js/
        └── main.js     ← Extracted JavaScript (for reference)
```

## Pages
- Home (Hero, Search, Featured Properties, Why Choose Us, Testimonials)
- Properties (All listings + filters)
- Land Listings
- Houses for Sale
- About Us
- Contact Us

## Before Publishing

1. Open `index.html` in any text editor
2. Search for `2348000000000` → replace with your real WhatsApp number
3. Search for `info@cludeworldproperties.com` → replace with your real email
4. Search for `14 Victoria Island Boulevard` → replace with your real address
5. Replace the Google Maps iframe src with your real office location embed

## Tech Stack
- Pure HTML5, CSS3, JavaScript (no frameworks, no dependencies)
- Google Fonts (loaded from CDN)
- Images from Unsplash (CDN — no download needed)

## Support
For customizations, contact your developer.
