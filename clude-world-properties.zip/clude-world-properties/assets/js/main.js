// Clude World Properties - Main JavaScript
// This file is extracted for reference. The website runs from index.html

// ===== PROPERTY DATA =====
const properties = [
  {
    id:1, type:'land', subtype:'residential',
    name:'Serene Heights Estate – Plot A', price:4500000,
    location:'Epe, Lagos', badge:'Land', status:'Available',
    img:'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&q=70',
    desc:'Prime 600sqm residential plot in the fast-appreciating Epe corridor. Gated community, C of O available. Excellent for future development or investment hold.',
    features:{size:'600 sqm', title:'C of O', access:'Good Road'},
    beds:null, baths:null
  },
  {
    id:2, type:'house', subtype:'4bed',
    name:'Prestige Manor – Maitama', price:85000000,
    location:'Maitama, Abuja', badge:'House', status:'Available',
    img:'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600&q=70',
    desc:'Magnificent 4-bedroom detached duplex in the heart of Maitama. Fully fitted kitchen, modern finishes, BQ, 2 living rooms, and a landscaped garden.',
    features:{size:'520 sqm', title:'Deed', access:'Tarred Road'},
    beds:4, baths:5
  },
  {
    id:3, type:'land', subtype:'commercial',
    name:'Commercial Corner Plot – Lekki Phase 1', price:32000000,
    location:'Lekki Phase 1, Lagos', badge:'Land', status:'Available',
    img:'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=600&q=70',
    desc:'High-visibility 1,200sqm commercial plot on a major Lekki Phase 1 intersection. Ideal for mixed-use development. Governor\'s Consent available.',
    features:{size:'1,200 sqm', title:"Gov't Consent", access:'Dual Carriageway'},
    beds:null, baths:null
  },
  {
    id:4, type:'house', subtype:'5bed',
    name:'Lagoon View Mansion – VI', price:250000000,
    location:'Victoria Island, Lagos', badge:'House', status:'Available',
    img:'https://images.unsplash.com/photo-1613977257592-4a9a32f9141b?w=600&q=70',
    desc:'Ultra-premium 5-bedroom waterfront mansion on Victoria Island with panoramic lagoon views. Smart home technology, cinema room, rooftop terrace, and private jetty.',
    features:{size:'800 sqm', title:'C of O', access:'Waterfront'},
    beds:5, baths:6
  },
  {
    id:5, type:'land', subtype:'residential',
    name:'Green Valley Estate – Ibadan', price:2800000,
    location:'Ibadan, Oyo State', badge:'Land', status:'Available',
    img:'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=600&q=70',
    desc:'Affordable 450sqm residential plot in a serene Ibadan estate with all utilities. Perfect for first-time buyers and diaspora investment. Survey & Deed available.',
    features:{size:'450 sqm', title:'Survey+Deed', access:'Estate Road'},
    beds:null, baths:null
  },
  {
    id:6, type:'house', subtype:'3bed',
    name:'Emerald Terrace – Gwarinpa', price:45000000,
    location:'Gwarinpa, Abuja', badge:'House', status:'Available',
    img:'https://images.unsplash.com/photo-1605276374104-dee2a0ed3cd6?w=600&q=70',
    desc:'Tastefully finished 3-bedroom semi-detached house in Gwarinpa. Modern kitchen, tiled throughout, POP ceilings, 24/7 security, and dedicated parking.',
    features:{size:'300 sqm', title:'C of O', access:'Estate Road'},
    beds:3, baths:3
  },
  {
    id:7, type:'land', subtype:'farm',
    name:'Agricultural Hectares – Ogun State', price:6500000,
    location:'Sagamu, Ogun State', badge:'Land', status:'Available',
    img:'https://images.unsplash.com/photo-1500076656116-558758c991c1?w=600&q=70',
    desc:'5-hectare agricultural land ideal for farming investment, agribusiness, or future estate development. Rich laterite soil, water table present, survey included.',
    features:{size:'5 Hectares', title:'Survey', access:'Country Road'},
    beds:null, baths:null
  },
  {
    id:8, type:'house', subtype:'4bed',
    name:'The Palms Residence – Port Harcourt', price:65000000,
    location:'GRA Phase 2, Port Harcourt', badge:'House', status:'Available',
    img:'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=600&q=70',
    desc:'Executive 4-bedroom detached house in the prestigious GRA Phase 2. Fully tiled, quality fittings, generator house, borehole, and perimeter fence.',
    features:{size:'450 sqm', title:'C of O', access:'Tarred Road'},
    beds:4, baths:4
  },
  {
    id:9, type:'land', subtype:'residential',
    name:'Sunrise Court – Ibeju-Lekki', price:8500000,
    location:'Ibeju-Lekki, Lagos', badge:'Land', status:'Available',
    img:'https://images.unsplash.com/photo-1501854140801-50d01698950b?w=600&q=70',
    desc:'Strategic 600sqm plot in the booming Ibeju-Lekki corridor — proximity to Dangote Refinery and Lekki Free Zone guarantees explosive appreciation.',
    features:{size:'600 sqm', title:'C of O', access:'Good Road'},
    beds:null, baths:null
  },
  {
    id:10, type:'apartment', subtype:'3bed',
    name:'Skyline Apartments – Wuse 2', price:38000000,
    location:'Wuse 2, Abuja', badge:'Apartment', status:'Available',
    img:'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=600&q=70',
    desc:'Luxury 3-bedroom apartment in a 12-floor residential tower in Wuse 2. Floor-to-ceiling glass, gym, swimming pool, concierge, and underground parking.',
    features:{size:'210 sqm', title:'C of O', access:'City Centre'},
    beds:3, baths:3
  },
  {
    id:11, type:'land', subtype:'residential',
    name:'Lakeside Plots – Enugu', price:3200000,
    location:'Independence Layout, Enugu', badge:'Land', status:'Available',
    img:'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&q=70',
    desc:'Beautiful lakeside 500sqm plots in a serene Enugu estate. Calm environment, suitable for retirement home or residential development. Survey & allocation letters available.',
    features:{size:'500 sqm', title:'Survey', access:'Estate Road'},
    beds:null, baths:null
  },
  {
    id:12, type:'house', subtype:'5bed',
    name:'Royal Court Estate – Lekki Phase 2', price:180000000,
    location:'Lekki Phase 2, Lagos', badge:'House', status:'Available',
    img:'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=600&q=70',
    desc:'Spectacular 5-bedroom fully detached smart home in a gated Lekki Phase 2 estate. Home office, cinema, rooftop lounge, solar backup, and concierge services.',
    features:{size:'650 sqm', title:'C of O', access:'Estate'},
    beds:5, baths:6
  }
];

function formatPrice(p) {
  if (p >= 1000000000) return '₦' + (p/1000000000).toFixed(1) + 'B';
  if (p >= 1000000) return '₦' + (p/1000000).toFixed(1) + 'M';
  return '₦' + p.toLocaleString();
}

function createCard(p) {
  const featsHtml = p.beds
    ? `<div class="prop-features">
        <div class="feat"><strong>${p.beds}</strong> Beds</div>
        <div class="feat"><strong>${p.baths}</strong> Baths</div>
        <div class="feat"><strong>${p.features.size}</strong></div>
       </div>`
    : `<div class="prop-features">
        <div class="feat"><strong>${p.features.size}</strong></div>
        <div class="feat"><strong>${p.features.title}</strong></div>
        <div class="feat"><strong>${p.features.access}</strong></div>
       </div>`;
  return `
    <div class="prop-card reveal" onclick='openModal(${p.id})'>
      <div class="prop-img-wrap">
        <img src="${p.img}" alt="${p.name}" loading="lazy">
        <div class="prop-badge ${p.type === 'land' ? 'land' : ''}">${p.badge}</div>
        <div class="prop-status">● ${p.status}</div>
      </div>
      <div class="prop-body">
        <div class="prop-price">${formatPrice(p.price)}</div>
        <div class="prop-name">${p.name}</div>
        <div class="prop-location">
          <svg width="13" height="13" fill="none" stroke="var(--gold)" stroke-width="2" viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
          ${p.location}
        </div>
        <div class="prop-desc">${p.desc.substring(0,100)}...</div>
        ${featsHtml}
      </div>
    </div>`;
}

function renderGrid(containerId, items) {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = items.map(createCard).join('');
  observeReveal();
}

// ===== PAGE ROUTING =====
const pages = ['home','properties','land','houses','about','contact'];
function showPage(name) {
  pages.forEach(p => {
    document.getElementById('page-'+p).classList.remove('active');
    const nav = document.getElementById('nav-'+p);
    if (nav) nav.classList.remove('active');
  });
  document.getElementById('page-'+name).classList.add('active');
  const nav = document.getElementById('nav-'+name);
  if (nav) nav.classList.add('active');
  window.scrollTo({top:0,behavior:'smooth'});
  populatePage(name);
  setTimeout(observeReveal, 100);
}

function populatePage(name) {
  if (name === 'home') renderGrid('featuredGrid', properties.slice(0,3));
  if (name === 'properties') renderGrid('allPropsGrid', properties);
  if (name === 'land') renderGrid('landGrid', properties.filter(p=>p.type==='land'));
  if (name === 'houses') renderGrid('housesGrid', properties.filter(p=>p.type==='house'));
}

// ===== FILTER FUNCTIONS =====
function filterProps(type, btn) {
  document.querySelectorAll('#page-properties .filter-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  const items = type === 'all' ? properties : properties.filter(p=>p.type===type||p.subtype===type);
  renderGrid('allPropsGrid', items);
}
function filterLand(type, btn) {
  document.querySelectorAll('#page-land .filter-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  const items = type === 'all' ? properties.filter(p=>p.type==='land') : properties.filter(p=>p.type==='land'&&p.subtype===type);
  renderGrid('landGrid', items);
}
function filterHouses(type, btn) {
  document.querySelectorAll('#page-houses .filter-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  const items = type === 'all' ? properties.filter(p=>p.type==='house') : properties.filter(p=>p.type==='house'&&p.subtype===type);
  renderGrid('housesGrid', items);
}
function filterByLocation() {
  const loc = document.getElementById('locationFilter').value;
  const items = loc ? properties.filter(p=>p.location.includes(loc)) : properties;
  renderGrid('allPropsGrid', items);
}
function filterByPrice() {
  const val = document.getElementById('priceFilter').value;
  if (!val) { renderGrid('allPropsGrid', properties); return; }
  const [min,max] = val.split('-').map(Number);
  renderGrid('allPropsGrid', properties.filter(p=>p.price>=min&&p.price<=max));
}
function filterLandByLoc() {
  const loc = document.getElementById('landLocationFilter').value;
  const items = properties.filter(p=>p.type==='land'&&(!loc||p.location.includes(loc)));
  renderGrid('landGrid', items);
}
function filterHouseByLoc() {
  const loc = document.getElementById('houseLocationFilter').value;
  const items = properties.filter(p=>p.type==='house'&&(!loc||p.location.includes(loc)));
  renderGrid('housesGrid', items);
}

// ===== SEARCH =====
function doSearch() {
  const q = document.getElementById('heroSearch').value.toLowerCase();
  const type = document.getElementById('heroType').value.toLowerCase();
  const loc = document.getElementById('heroLocation').value;
  showPage('properties');
  setTimeout(() => {
    const items = properties.filter(p => {
      const matchQ = !q || p.name.toLowerCase().includes(q) || p.location.toLowerCase().includes(q) || p.desc.toLowerCase().includes(q);
      const matchType = !type || p.type === type || p.badge.toLowerCase() === type;
      const matchLoc = !loc || p.location.includes(loc);
      return matchQ && matchType && matchLoc;
    });
    renderGrid('allPropsGrid', items.length ? items : properties);
  }, 300);
}

// ===== MODAL =====
function openModal(id) {
  const p = properties.find(x=>x.id===id);
  if (!p) return;
  document.getElementById('modalImg').src = p.img;
  document.getElementById('modalImg').alt = p.name;
  document.getElementById('modalBadge').textContent = p.badge;
  document.getElementById('modalPrice').textContent = formatPrice(p.price);
  document.getElementById('modalName').textContent = p.name;
  document.getElementById('modalLoc').textContent = p.location;
  document.getElementById('modalDesc').textContent = p.desc;
  document.getElementById('modalWhatsapp').href = `https://wa.me/2348000000000?text=I'm%20interested%20in%20${encodeURIComponent(p.name)}`;
  let feats = `<div class="modal-feat"><div class="modal-feat-val">${p.features.size}</div><div class="modal-feat-label">Size</div></div>
               <div class="modal-feat"><div class="modal-feat-val">${p.features.title}</div><div class="modal-feat-label">Title</div></div>
               <div class="modal-feat"><div class="modal-feat-val">${p.features.access}</div><div class="modal-feat-label">Access</div></div>`;
  if (p.beds) feats += `<div class="modal-feat"><div class="modal-feat-val">${p.beds}</div><div class="modal-feat-label">Bedrooms</div></div>
                        <div class="modal-feat"><div class="modal-feat-val">${p.baths}</div><div class="modal-feat-label">Bathrooms</div></div>`;
  document.getElementById('modalFeatsGrid').innerHTML = feats;
  document.getElementById('propModal').classList.add('open');
}
function closeModal(e) {
  if (e.target.id === 'propModal') document.getElementById('propModal').classList.remove('open');
}

// ===== MOBILE MENU =====
function toggleMenu() {
  document.getElementById('mobileMenu').classList.toggle('open');
}

// ===== SCROLL REVEAL =====
function observeReveal() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); observer.unobserve(e.target); } });
  }, { threshold: 0.1 });
  document.querySelectorAll('.reveal:not(.visible)').forEach(el => observer.observe(el));
}

// ===== FORM SUBMIT =====
function submitForm() {
  alert('Thank you! Your message has been received. A consultant will contact you within 24 hours.\n\nFor immediate assistance, please WhatsApp us: +234 800 000 0000');
}

// ===== INIT =====
populatePage('home');
setTimeout(observeReveal, 200);